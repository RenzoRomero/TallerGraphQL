// src/App.js
import React from 'react';
import Products from './Products';  // Importa el componente Products

const App = () => {
  return (
    <div>
      <h1>Bienvenido a la Tienda</h1>
      <Products />  {/* Muestra el componente Products */}
    </div>
  );
};

export default App;