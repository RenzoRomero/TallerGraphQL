// src/index.js
import React from 'react';
import ReactDOM from 'react-dom/client';  // Asegúrate de usar react-dom/client
import { ApolloProvider } from '@apollo/client/react';  // Desde @apollo/client
import App from './App';
import client from './ApolloClient';  // Importamos el cliente Apollo configurado

// Crear la raíz del DOM con createRoot
const root = ReactDOM.createRoot(document.getElementById('root'));

// Renderizar la aplicación con ApolloProvider
root.render(
  <ApolloProvider client={client}>
    <App />
  </ApolloProvider>
);