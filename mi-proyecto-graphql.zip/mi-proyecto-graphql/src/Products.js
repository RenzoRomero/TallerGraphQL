import React, { useState } from 'react';
import { gql } from '@apollo/client';
import { useQuery, useMutation } from '@apollo/client/react';

// Define la consulta GraphQL para obtener los productos
const GET_PRODUCTS = gql`
  query GetAllProducts {
    getAllProducts {
      id
      name
      price
      stock
    }
  }
`;

// Define la mutación para crear un producto
const CREATE_PRODUCT = gql`
  mutation CreateProduct($input: ProductRequest!) {
    createProduct(input: $input) {
      id
      name
      price
      stock
    }
  }
`;

const Products = () => {
  // Estado para los nuevos datos del producto
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [stock, setStock] = useState('');

  // Ejecuta la consulta de productos
  const { loading, error, data } = useQuery(GET_PRODUCTS);

  // Ejecuta la mutación para crear un producto
  const [createProduct] = useMutation(CREATE_PRODUCT, {
    refetchQueries: [{ query: GET_PRODUCTS }],  // Refrescar la lista de productos después de agregar uno
  });

  // Función para manejar el envío del formulario
  const handleAddProduct = async (e) => {
    e.preventDefault();

    // Preparar los datos para la mutación
    const input = {
      name,
      price: parseFloat(price),
      stock: parseInt(stock),
    };

    try {
      // Ejecutar la mutación
      await createProduct({ variables: { input } });
      setName('');
      setPrice('');
      setStock('');
    } catch (err) {
      console.error('Error al crear el producto:', err);
    }
  };

  if (loading) return <p>Cargando productos...</p>;
  if (error) return <p>Error: {error.message}</p>;

  return (
    <div>
      <h1>Productos</h1>

      {/* Formulario para agregar un producto */}
      <form onSubmit={handleAddProduct}>
        <div>
          <label>Nombre:</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Precio:</label>
          <input
            type="number"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Stock:</label>
          <input
            type="number"
            value={stock}
            onChange={(e) => setStock(e.target.value)}
            required
          />
        </div>
        <button type="submit">Agregar Producto</button>
      </form>

      <ul>
        {data.getAllProducts.map((product) => (
          <li key={product.id}>
            <strong>{product.name}</strong> - ${product.price} - Stock: {product.stock}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Products;